hip = 0
spine = 1
shoulder = 2
head = 3
las = 4 
lae = 5 
law = 6 
lah = 7 
ras = 8
rae = 9
raw = 10
rah = 11
llh = 12 
llk = 13 
lla = 14 
llf = 15 
rlh = 16
rlk = 17
rla = 18
rlf = 19 

joints = dict( 
  hip = hip,
  spine = spine,
  shoulder = shoulder,
  head = head,
  las = las, ras = ras,
  lae = lae, rae = rae,
  law = law, raw = raw,
  lah = lah, rah = rah,
  llh = llh, rlh = rlh,
  llk = llk, rlk = rlk,
  lla = lla, rla = rla,
  llf = llf, rlf = rlf )

jointNeighbours = [
  ( 0, 1 ), ( 1, 2 ), ( 2, 3 ),
  ( 2, 4 ), ( 4, 5 ), ( 5, 6 ), ( 6, 7 ),
  ( 2, 8 ), ( 8, 9 ), ( 9, 10 ), ( 10, 11 ),
  ( 0, 12 ), ( 12, 13 ), ( 13, 14 ), ( 14, 15 ),
  ( 0, 16 ), ( 16, 17 ), ( 17, 18, ( 18, 19 ) )
]
