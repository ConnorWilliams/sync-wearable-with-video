import matplotlib.pyplot as pl
from scipy.io import loadmat 
import numpy as np
import joints as joints

from mpl_toolkits.mplot3d import Axes3D

from filter import smooth

import gzip
import cPickle as pickle


from sklearn.decomposition import PCA




def getCoords( data, measurement ):
  a = measurement[0]
  b = measurement[1]

  this1 = data[:, np.arange( 3 ) + 3 * a[0]]
  that1 = data[:, np.arange( 3 ) + 3 * a[1]]
  this2 = data[:, np.arange( 3 ) + 3 * b[0]]
  that2 = data[:, np.arange( 3 ) + 3 * b[1]]
  
  sd = np.copy( this1 - that1 )
  wd = np.copy( this2 - that2 )
  
  return this1, that1, this2, that2, sd, wd



def getAngles( data, measurement ):
  _, _, _, _, sd, wd = getCoords( data, measurement )
  
  dot = ( wd * sd ).sum( 1 )
  wn = np.sum( np.sqrt( wd ** 2.0 ), 1 )
  sn = np.sum( np.sqrt( sd ** 2.0 ), 1 )
  
  val = ( dot / ( wn * sn ) )
  
  return val



def drawSkeleton( example ): 
  for n in joints.jointNeighbours:
    a = example[np.arange( 3 ) + 3 * n[0]]
    b = example[np.arange( 3 ) + 3 * n[1]]
    pl.plot( [a[0], b[0]], [a[2], b[2]], [a[1], b[1]], marker = "o", c = "k" )



def plotJointMovements( examples, jointMeasurements ):
  for measurement in jointMeasurements:
    _, _, _, _, sd, wd = getCoords( examples, measurement )
    
    for i in np.arange( len( examples ) ):
      pl.plot( [sd[i, 0], wd[i, 0]],
               [sd[i, 2], wd[i, 2]],
               [sd[i, 1], wd[i, 1]] )
  


data = pickle.load( gzip.open( "kinect2.pkl.gz", "rb " ) )
data = np.asarray( [smooth( d, 3, "flat" ) for d in data.T] ).T





# Measure this joint's position relative to that joint's position: 
# [ (this1,that1), (this2,that2) ]
jointMeasurements = [
  [( joints.ras, joints.rae ), ( joints.raw, joints.rae )], # Elbow joint
  [( joints.ras, joints.rae ), ( joints.spine, joints.shoulder )], # Elbow WRT spine
  [( joints.ras, joints.raw ), ( joints.spine, joints.shoulder )], # Wrist WRT spine
  [( joints.ras, joints.rae ), ( joints.ras, joints.shoulder )], # Elbow WRT shoulder
  [( joints.ras, joints.raw ), ( joints.ras, joints.shoulder )], # Wrist WRT shoulder
  [( joints.raw, joints.rae ), ( joints.shoulder, joints.head )],
  
  [( joints.las, joints.lae ), ( joints.raw, joints.rae )], # Elbow joint
  [( joints.las, joints.lae ), ( joints.spine, joints.shoulder )], # Elbow WRT spine
  [( joints.las, joints.law ), ( joints.spine, joints.shoulder )], # Wrist WRT spine
  [( joints.las, joints.lae ), ( joints.ras, joints.shoulder )], # Elbow WRT shoulder
  [( joints.las, joints.law ), ( joints.ras, joints.shoulder )], # Wrist WRT shoulder
  [( joints.law, joints.lae ), ( joints.shoulder, joints.head )],
  
  [( joints.head, joints.shoulder ), ( joints.spine, joints.shoulder )], # Head WRT spine
  [( joints.head, joints.shoulder ), ( joints.spine, joints.ras )], # Head WRT shoulder
  [( joints.head, joints.shoulder ), ( joints.spine, joints.las )], # Head WRT shoulder
  [( joints.llh, joints.rlh ), ( joints.las, joints.ras )],
  [( joints.llh, joints.rlh ), ( joints.lae, joints.rae )],
  [( joints.llh, joints.rlh ), ( joints.law, joints.raw )],
  [( joints.llh, joints.rlh ), ( joints.llk, joints.rlk )],
  [( joints.llh, joints.rlh ), ( joints.lla, joints.rla )],
  
  [( joints.rlh, joints.rlk ), ( joints.rla, joints.rlk )],
  [( joints.rlk, joints.rla ), ( joints.rlf, joints.rla )],
  
  [( joints.llh, joints.llk ), ( joints.lla, joints.llk )],
  [( joints.llk, joints.lla ), ( joints.llf, joints.lla )],
]

angles = np.asarray( [getAngles( data, meas ) for meas in jointMeasurements] ).T


plotwin = 50


l = 1

minx = data[:, 0::3].min()
miny = data[:, 1::3].min()
minz = data[:, 2::3].min()
maxx = data[:, 0::3].max()
maxy = data[:, 1::3].max()
maxz = data[:, 2::3].max()



fig = pl.figure( figsize = ( 12.5, 5 ) )
ax_skeleton = fig.add_subplot( 1, 4, 1, projection = '3d' )

axes = [
  ( fig.add_subplot( 2, 4, 2 ), np.arange( 6 ) + 0 ),
  ( fig.add_subplot( 2, 4, 4 ), np.arange( 6 ) + 6 ),
  ( fig.add_subplot( 1, 4, 3 ), np.arange( 8 ) + 12 ),
  ( fig.add_subplot( 2, 4, 6 ), np.arange( 2 ) + 20 ),
  ( fig.add_subplot( 2, 4, 8 ), np.arange( 2 ) + 22 ),
]





for i in np.arange( plotwin / 2, len( data ) - plotwin / 2 ):
  ii = i - plotwin / 2
  
  r = np.arange( i - l, i )
  print ii
  
  
  ax_skeleton.cla()
  pl.sca( ax_skeleton )
  for j in r:
    drawSkeleton( data[j] )
  ax_skeleton.auto_scale_xyz( [minx, maxx], [miny, maxy], [minz, maxz] )
  ax_skeleton.xaxis.set_ticklabels( [] )
  ax_skeleton.yaxis.set_ticklabels( [] )
  ax_skeleton.zaxis.set_ticklabels( [] )
  
  
  
  plotRange = np.arange( i - plotwin / 2, i + plotwin / 2 )
  
  
  for ax, which in axes:
    ax.cla()
  
    x = plotRange
    y = angles[plotRange]
    y = y[:, which]
    
    ax.plot( x, y )
    
    ax.plot( [i, i], [-1, 1], 'k' )
    
    ax.set_xlim( i - plotwin / 2, i + plotwin / 2 )
    #ax.set_ylim( y.min(), y.max() )
    ax.set_ylim( -1, 1 )
    
    ax.xaxis.set_ticklabels( [] )
    ax.yaxis.set_ticklabels( [] )
  
  fig.tight_layout() 
  
  
  pl.savefig( "out/%05d.png" % ( ii ) )

